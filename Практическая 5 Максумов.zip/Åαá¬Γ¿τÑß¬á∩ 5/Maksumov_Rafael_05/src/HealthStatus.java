public enum HealthStatus {
    HEALTHY, SICK
}
